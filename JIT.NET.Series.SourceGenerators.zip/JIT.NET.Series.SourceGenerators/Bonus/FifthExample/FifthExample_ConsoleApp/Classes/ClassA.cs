﻿namespace FifthExample_ConsoleApp.Classes;

public class ClassA
{
    public int ClassAIntProperty { get; set; }
    public string ClassAStringProperty { get; set; }
}