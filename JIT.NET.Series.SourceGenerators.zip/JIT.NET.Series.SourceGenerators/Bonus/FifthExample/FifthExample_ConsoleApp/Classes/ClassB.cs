﻿namespace FifthExample_ConsoleApp.Classes;

public class ClassB
{
    public int ClassBIntProperty { get; set; }
    public string ClassBStringProperty { get; set; }
}