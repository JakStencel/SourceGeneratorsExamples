﻿namespace FifthExample_ConsoleApp.Classes;

public class ClassC
{
    public int ClassCIntProperty { get; set; }
    public string ClassCStringProperty { get; set; }
}