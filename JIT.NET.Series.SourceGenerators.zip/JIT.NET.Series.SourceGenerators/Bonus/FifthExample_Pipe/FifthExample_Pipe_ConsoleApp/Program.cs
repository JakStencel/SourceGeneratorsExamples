﻿// See https://aka.ms/new-console-template for more information


AdditionalFilesGenerated.AdditionalTextList.PrintTexts();
