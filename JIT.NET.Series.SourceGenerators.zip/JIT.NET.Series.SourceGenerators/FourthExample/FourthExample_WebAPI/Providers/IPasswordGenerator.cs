﻿namespace FourthExample_WebAPI.Providers;

public interface IPasswordGenerator 
{
    public string GenerateRandomPassword();
}