﻿namespace SecondExample_ConsoleApp;

public class Person
{
    public string? Name { get; set; }

    public string? FavoriteVehicle { get; set; }
}