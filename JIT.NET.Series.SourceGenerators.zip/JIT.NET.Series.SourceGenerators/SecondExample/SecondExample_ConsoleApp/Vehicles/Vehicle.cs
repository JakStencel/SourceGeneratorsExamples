﻿namespace SecondExample_ConsoleApp.Vehicles;

public class Vehicle
{
    protected string Name { get; set; }

    public Vehicle(string name)
    {
        Name = name;
    }
}