﻿namespace ThirdExample_AttributeLookup;

public class ImplementAttribute : Attribute
{
    public ImplementAttribute(string name)
    {

    }
}

public class DefineAttribute : Attribute
{

}